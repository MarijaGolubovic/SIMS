namespace SIMS.Model
{

    public class Menager //: User  ****Popravi

    {

    }
}