namespace SIMS.Model
{
    public enum UserType
    {
        patient,
        doctor,
        secretary,
        menager
    }
}