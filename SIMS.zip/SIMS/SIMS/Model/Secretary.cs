namespace SIMS.Model
{
    public class Secretary //: User
    {
    }
}