namespace SIMS.Model
{
    public enum RoomType
    {
        OPPERATING_ROOM,
        EXAMINATION_ROOM,
        HOSPITAL_ROOM,
        WAREHOUSE
    }
}