using System;
using System.Collections.Generic;

namespace SIMS.Model
{
    public class SpecializationStorage
    {
        public List<Specialization> GetAll()
        {
            throw new NotImplementedException();
        }

        public Boolean Create(Specialization specialization)
        {
            throw new NotImplementedException();
        }

        public Boolean Update(Specialization specialization)
        {
            throw new NotImplementedException();
        }

        public String fileName;

    }
}