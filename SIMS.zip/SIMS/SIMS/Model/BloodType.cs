namespace SIMS.Model
{
    public enum BloodType
    {
        aPositive,
        aNegative,
        bPositive,
        bNegative,
        abPositive,
        abNegative,
        oPositive,
        oNegative
    }
}