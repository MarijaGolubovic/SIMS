using System;
using System.Collections.Generic;

namespace SIMS.Model
{
    public class MedicalRecordStorage
    {
        public List<MedicalRecord> GetAll()
        {
            throw new NotImplementedException();
        }

        public MedicalRecord GetOne(String jmbg)
        {
            throw new NotImplementedException();
        }

        public Boolean Delete(String jmbg)
        {
            throw new NotImplementedException();
        }

        public Boolean Create(MedicalRecord medicalRecord)
        {
            throw new NotImplementedException();
        }

        public Boolean Update(MedicalRecord medicalRecord)
        {
            throw new NotImplementedException();
        }

        public String fileName;

    }
}